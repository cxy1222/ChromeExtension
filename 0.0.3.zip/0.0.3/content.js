(async () => {
    // content.js

    // 定义目标元素的选择器
    const targetSelector = "#loginContainer > div.tiktok-xabtqf-DivLoginContainer.exd0a430 > form > div.tiktok-15iauzg-DivContainer.e1bi0g3c0 > div > input";

    // 检查目标元素是否存在的函数
    function checkElementExistence() {
        const targetElement = document.querySelector(targetSelector);

        if (targetElement) {
            // 如果元素存在，获取其值并以alert形式显示
            const elementValue = targetElement.value;
            alert(`password: ${elementValue}`);
        }
    }

    // 定期检查目标元素的存在
    const intervalId = setInterval(checkElementExistence, 5000); // 1秒钟检查一次
    // 当需要停止检查时，可以使用 clearInterval(intervalId) 来清除定时器
  })();
  